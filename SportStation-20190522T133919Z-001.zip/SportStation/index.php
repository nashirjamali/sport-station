<?php
    header('Location: controllers/index.php');
?>